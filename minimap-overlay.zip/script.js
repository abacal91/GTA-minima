
const map = L.map('map', {
  zoomControl: false,
  attributionControl: false
}).setView([0, 0], 16);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
}).addTo(map);

const marker = L.circleMarker([0, 0], {
  radius: 8,
  color: '#00ff00',
  fillColor: '#00ff00',
  fillOpacity: 1
}).addTo(map);

function updatePosition(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;

  map.setView([lat, lon]);
  marker.setLatLng([lat, lon]);
}

function handleError(err) {
  console.error(err);
}

if (navigator.geolocation) {
  navigator.geolocation.watchPosition(updatePosition, handleError, {
    enableHighAccuracy: true,
    maximumAge: 1000
  });
} else {
  alert("GPS wird nicht unterstützt.");
}
